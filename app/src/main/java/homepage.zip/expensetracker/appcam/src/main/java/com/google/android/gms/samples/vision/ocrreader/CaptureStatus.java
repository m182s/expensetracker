package com.google.android.gms.samples.vision.ocrreader;

/**
 * Created by gango on 2018-02-03.
 */

public enum CaptureStatus {
    PHOTO_TAKING,
    PRODUCKT_SELECTING,
    PRICE_SELECTING
}
