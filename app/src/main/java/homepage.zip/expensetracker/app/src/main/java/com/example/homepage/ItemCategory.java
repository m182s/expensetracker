package com.example.homepage;

public enum ItemCategory {
    All,// 0
    Travel, //1
    Food, //2
    Fashion, //3
    Uncategorized //4
}
