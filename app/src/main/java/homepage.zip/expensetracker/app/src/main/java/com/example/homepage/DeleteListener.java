package com.example.homepage;

public interface DeleteListener
{
    void onDelete(int position);
}
